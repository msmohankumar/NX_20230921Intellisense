------------------------------------------------------------------------------------

       Copyright 2023 Siemens Digital Industries Software.
                           All Rights Reserved.

------------------------------------------------------------------------------------



------------------------------------------------------------------------------------
                        Diagramming Customer Program Example
------------------------------------------------------------------------------------

-----------
Description
-----------
    This example demonstrates for customers about how to create elements (symbols, connections, tables, etc.) on a diagramming sheet by playing the journal in NX.
    This example uses a journal recorded using the Python programming language.

--------------
Files required
--------------
    DiagrammingCustomerProgram.py

----------------------------
Build steps
----------------------------

   Windows
  ---------
    -NA-
  
   Linux
   -------
    -NA-
    
----------------------------
Settings before Launching NX
----------------------------
    None

----------------------------
Settings after Launching NX
----------------------------
    None

--------------------------
Example execution steps
--------------------------

    1. Start NX with managed mode.

    2. Execute the journal:

        2.1 Journal execution
            -----------------
            Invoke DiagrammingCustomerProgram.py file
            using Developer tab > Journal > Play... (Alt+F8)
------
Notes
------
    NXOpen application must be signed before its release. If not signed the application may not get executed.
    For more details on signing the application refer to NXOpen Programmer's Guide.
    This .py file should RUN in non-system context mode.
-----------
CAVEATS
-----------

    None

