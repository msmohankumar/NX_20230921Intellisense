'===================================================================================================
'               Copyright 2017 Siemens Product Lifecycle Management Software Inc.
'===================================================================================================
'
'    NOTE:  NX Development provides programming examples for illustration only.
'    NX Development assumes you are familiar with the programming language
'    demonstrated in these examples, and the tools used to create and debug NX/Open
'    programs. GTAC support professionals can help explain the functionality of
'    a particular procedure, but neither GTAC nor NX Development will modify
'    these examples to provide added functionality or construction procedures.
'
'File description:
'
'    A Visual Basic module that implements example Routing plugins.
'
'
'===================================================================================================
Option Strict On
Imports System.Windows.Forms
Imports NXOpen
Imports NXOpen.Routing
Imports NXOpen.Routing.Electrical
Imports NXOpen.Routing.CustomManager
Imports NXOpen.Preferences
Imports NXOpen.Utilities
Imports NXOpen.UF

Module Plugins

    Dim theSession As Session = Nothing
    Dim listingWindow As ListingWindow = Nothing
    Dim customManager As CustomManager = Nothing
    Dim rsdCustomManager As RoutingCommon.CustomManager = Nothing
    Dim createPathRuleId As Integer = 0
    Dim subdivideSegmentRuleId As Integer = 0

    '-----------------------------------------------------------------------------------------------
    ' Called when NX starts up to register the plugins.
    Function Startup(ByVal args As String()) As Integer

        If theSession Is Nothing Then
            theSession = Session.GetSession()
        End If

        If listingWindow Is Nothing Then
            listingWindow = theSession.ListingWindow
        End If

        If customManager Is Nothing Then
            customManager = theSession.RouteCustomManager()
        End If

        If rsdCustomManager Is Nothing Then
            rsdCustomManager = theSession.RoutingCustomManager()
        End If

        RegisterPlugins()

        theSession.LicenseManager.ReleaseAll(Nothing)

        Startup = 0
    End Function

    '------------------------------------------------------------------------------------------
    ' Called from File->Execute->NX Open. Useful for testing.
    Sub Main()

        If theSession Is Nothing Then
            theSession = Session.GetSession()
        End If

        If listingWindow Is Nothing Then
            listingWindow = theSession.ListingWindow
        End If

        If customManager Is Nothing Then
            customManager = theSession.RouteCustomManager()
        End If

        If rsdCustomManager Is Nothing Then
            rsdCustomManager = theSession.RoutingCustomManager()
        End If

        RegisterPlugins()
    End Sub

    '------------------------------------------------------------------------------------------
    ' Called by both Main And Startup to register the plugins.
    Sub RegisterPlugins()

        customManager.SetHrnPreImportPlugin(AddressOf ImportExportPlugin)
        customManager.SetHrnPostExportPlugin(AddressOf ImportExportPlugin)
        customManager.SetCmpPreImportPlugin(AddressOf ImportExportPlugin)
        customManager.SetCmpPostExportPlugin(AddressOf ImportExportPlugin)
        customManager.SetPlmXmlPreImportPlugin(AddressOf ImportExportPlugin)
        customManager.SetPlmXmlPostExportPlugin(AddressOf ImportExportPlugin)
        customManager.SetPlmXmlRouteNodeNamePlugin(AddressOf RouteNodeNamePlugin)
        customManager.SetPlmXmlRouteSectionNamePlugin(AddressOf RouteSectionNamePlugin)
        customManager.SetWrappedOverstockLengthCalculationPlugin(AddressOf WrappedOverstockLengthCalculationPlugin)
        customManager.SetFilterBlankingPlugin(AddressOf FilterBlankingPlugin)
        customManager.SetBomPlugin(AddressOf BomPlugin)
        customManager.SetAutoRoutePlugin(AddressOf AutoRoutePlugin)
        customManager.SetManualRoutePlugin(AddressOf ManualRoutePlugin)
        customManager.SetUnroutePlugin(AddressOf UnroutePlugin)
        customManager.SetNavigatorObjectSelectedPlugin(AddressOf NavigatorObjectSelectedPlugin)
        customManager.SetValidateFormboardPlugin(AddressOf ValidateFormboardPlugin)
        customManager.SetDisciplineChangedPlugin(AddressOf DisciplineChangedPlugin)
        customManager.SetSpecificationChangedPlugin(AddressOf SpecificationChangedPlugin)
        customManager.SetSortConnectionsPlugin(AddressOf SortConnectionsPlugin)
        customManager.SetChoosePartPlugin(AddressOf ChoosePartPlugin)
        customManager.SetApplicationEnterPlugin(AddressOf ApplicationEnterPlugin)
        customManager.SetApplicationExitPlugin(AddressOf ApplicationExitPlugin)

        ' Routing calls the stock component name plugin when creating permanent stock using the
        ' Convert to Stock as Components command.
        customManager.SetStockComponentNamePlugin(AddressOf StockComponentNamePlugin)
        rsdCustomManager.SetWiringComponentNamePlugin(AddressOf StockComponentNamePlugin)

        ' Routing calls the temporary stock component name plugin when you are creating stocks
        ' on the fly in Stock as Components mode.
        customManager.SetTemporaryStockComponentNamePlugin(AddressOf StockComponentNamePlugin)

    End Sub

    '-----------------------------------------------------------------------------------------------
    Sub ImportExportPlugin(ByVal fileName As String)
        Echo("*** ImportExportPlugin called with " + fileName + "." + vbCrLf)
    End Sub

    '-----------------------------------------------------------------------------------------------
    Function RouteNodeNamePlugin() As String
        Echo("*** RouteNodeNamePlugin called")

        Return "RNx"
    End Function

    '-----------------------------------------------------------------------------------------------
    Function RouteSectionNamePlugin() As String
        Echo("*** RouteSectionNamePlugin called")

        Return "RSx"
    End Function

    '-----------------------------------------------------------------------------------------------
    Function WrappedOverstockLengthCalculationPlugin(ByVal overstock As Overstock) As Double
        Echo("*** Wrapped Overstock Length Calculation plugin called with overstock tag " + overstock.Tag.ToString())

        Return 10.0
    End Function

    '-----------------------------------------------------------------------------------------------
    Function FilterBlankingPlugin(ByVal segmentOrComponent As NXObject, ByVal logicalAttributeTitle As String, ByVal logicalAttributeValue As String, ByVal variableBuildString As String) As Boolean

        Echo("*** Filter Blanking plugin called with object tag tag " + segmentOrComponent.Tag.ToString())

        Dim electricalPreferences As RoutingElectrical = theSession.Preferences.RoutingApplicationView.RoutingElectrical

        Dim apvAttributeTitle As String = electricalPreferences.GetFilterBlankingAttribute

        Echo("    APV Attribute Title    : " + apvAttributeTitle)
        Echo("    Logical Attribute Title: " + logicalAttributeTitle)

        If logicalAttributeTitle <> apvAttributeTitle Then
            Echo("    (Not the same attribute titles. Ignoring this object.)")
            Return False
        End If

        logicalAttributeValue = logicalAttributeValue.ToUpper()

        Dim blankTheObject As Boolean = logicalAttributeValue Is "YES" Or
                                        logicalAttributeValue Is "TRUE" Or
                                        logicalAttributeValue Is "1"

        Echo("    Logical Attribute Value: " + logicalAttributeValue)
        Echo("    Variable Build String  : " + variableBuildString)

        If (blankTheObject) Then
            Echo("    Blank the object!")
        End If

        Echo("")

        FilterBlankingPlugin = blankTheObject

    End Function

    '-----------------------------------------------------------------------------------------------
    Sub BomPlugin()
        Echo("*** BomPlugin called." + vbCrLf)
    End Sub

    '-----------------------------------------------------------------------------------------------
    Function AutoRoutePlugin(ByVal connections As Connection()) As Integer
        Echo(vbCrLf + "*** Autoroute plugin called with " + connections.Length.ToString() + " connections.")

        For Each connection As Connection In connections
            Echo("  Connection Tag " + connection.Tag.ToString())
        Next

        AutoRoutePlugin = 0
    End Function

    '-----------------------------------------------------------------------------------------------
    Function ManualRoutePlugin(ByVal connections As Connection()) As Integer
        Echo(vbCrLf + "*** ManualRoute plugin called with " + connections.Length.ToString() + " connections.")

        For Each connection As Connection In connections
            Echo("  Connection Tag " + connection.Tag.ToString())
        Next

        ManualRoutePlugin = 0
    End Function

    '-----------------------------------------------------------------------------------------------
    Function UnroutePlugin(ByVal connections As Connection()) As Integer
        Echo(vbCrLf + "*** Unroute plugin called with " + connections.Length.ToString() + " connections.")

        For Each connection As Connection In connections
            Echo("  Connection Tag " + connection.Tag.ToString())
        Next

        UnroutePlugin = 0
    End Function

    '-----------------------------------------------------------------------------------------------
    Sub NavigatorObjectSelectedPlugin(ByVal navigatorType As NavigatorType, ByVal selectionType As SelectionType, ByVal selectedObjects As NXObject())

        Dim message As String = vbCrLf + "*** NavigatorObjectSelectedPlugin called with " + selectedObjects.Length.ToString()

        If selectionType = selectionType.Selected Then
            message += " selected"
        Else
            message += " deselected"
        End If

        If navigatorType = navigatorType.Connection Then
            message += " in the Connection Navigator."
        Else
            message += " in the Component Navigator."
        End If

        Echo(message)

        For Each selectedObject As NXObject In selectedObjects
            Echo("    Object tag " + selectedObject.Tag.ToString())
        Next

    End Sub

    '-----------------------------------------------------------------------------------------------
    Function ValidateFormboardPlugin(ByVal harnessDevices As HarnessDevice()) As Boolean
        Echo(vbCrLf + "*** ValidateFormboard plugin called with " + harnessDevices.Length.ToString() + " harness devices.")

        For Each harnessDevice As HarnessDevice In harnessDevices
            Echo("    Harness tag " + harnessDevice.Tag.ToString())
        Next

        ValidateFormboardPlugin = True
    End Function

    '-----------------------------------------------------------------------------------------------
    Sub DisciplineChangedPlugin(ByVal previousDisciplineName As String, ByVal newDisciplineName As String)
        Echo("*** Visual Basic Discipline Changed plugin called.")
        Echo("    Previous discipline name '" + previousDisciplineName + "'")
        Echo("    New discipline name      '" + newDisciplineName + "'")
    End Sub

    '-----------------------------------------------------------------------------------------------
    Sub SpecificationChangedPlugin(ByVal previousSpecificationName As String, ByVal newSpecificationName As String)
        Echo("*** Visual Basic Specification Changed plugin called.")
        Echo("    Previous specification name '" + previousSpecificationName + "'")
        Echo("    New specification name      '" + newSpecificationName + "'")
    End Sub

    '-----------------------------------------------------------------------------------------------
    Sub SortConnectionsPlugin(ByVal dataObject As SortConnectionsPluginData)
        Dim stockDevices() As ElectricalStockDevice = Nothing
        dataObject.GetStockDevicesToSort(stockDevices)

        Echo("*** VB Sort Connections plugin called with " + stockDevices.Length.ToString() + " stock devices.")

        Dim stockDeviceTags(stockDevices.Length - 1) As Tag
        Dim index = 0
        For Each stockDevice As ElectricalStockDevice In stockDevices
            Echo("  Stock Device Tag " + stockDevice.Tag.ToString() + ".")
            stockDeviceTags(index) = stockDevice.Tag
            index += 1
        Next

        Array.Sort(stockDeviceTags)

        Echo("")
        Dim sortedStockDevices(stockDevices.Length - 1) As ElectricalStockDevice

        index = 0
        For Each stockDeviceTag As Tag In stockDeviceTags
            Echo("  Sorted Stock Device Tag " + stockDeviceTag.ToString() + ".")
            sortedStockDevices(index) = CType(NXObjectManager.Get(stockDeviceTag), ElectricalStockDevice)
            index += 1
        Next

        dataObject.SetSortedStockDevices(sortedStockDevices)

    End Sub

    '-----------------------------------------------------------------------------------------------
    ' Implements an example Choose Part plugin that is used by the Place Part command.
    '
    ' You will have to add a reference to the Assemblies Framework System.Windows.Forms to use
    ' the OpenFileDialog class shown in this example.
    Function ChoosePartPlugin(ByVal dataObject As ChoosePartPluginData) As Integer

        Dim openFileDialog As OpenFileDialog = New OpenFileDialog()

        openFileDialog.Title = "Choose a part to place"
        openFileDialog.DefaultExt = "prt"
        openFileDialog.Filter = "part files (*.prt)|*.prt|All files (*.*)|*.*"
        openFileDialog.CheckFileExists = True
        openFileDialog.CheckPathExists = True

        Dim result As DialogResult = openFileDialog.ShowDialog()
        If (result = DialogResult.Cancel) Then
            Return -1
        End If

        Dim fullPath As String = openFileDialog.FileName

        ' At this point, you could open the part to get some of the part attributes from it.
        ' For this example, we are just going to return a few default values to Routing.
        dataObject.SetPartName(fullPath)
        dataObject.SetPartNumber("ExamplePartNumber001")
        dataObject.SetMemberName("") ' No member name since this Is Not a member Of a part family.

        ' Some example attributes.
        Dim exampleCharacteristics As CharacteristicList = theSession.Preferences.RoutingApplicationView.PartPreferences.PartLibrary.CreateCriteria()
        exampleCharacteristics.SetCharacteristic("USER_CHARX_TITLE1", "User_charx_value1")
        exampleCharacteristics.SetCharacteristic("USER_CHARX_TITLE2", "User_charx_value2")

        dataObject.SetCharacteristics(exampleCharacteristics)

        Return 0

    End Function

    '-----------------------------------------------------------------------------------------------
    ' The stock component name plugin Is given a data object that needs to be filled out completely.
    Sub StockComponentNamePlugin(dataObject As ComponentNamePluginData)

        Echo("StockComponentNamePlugin")

        Static stockNumberCounter As Integer = 0
        stockNumberCounter += 1

        Dim stockName As String = "StockComponent_" + stockNumberCounter.ToString("D4")
        Dim homeFolder As String = ""

        Dim ufSession As UFSession = ufSession.GetUFSession()
        Dim isManagedMode As Boolean = False

        ufSession.UF.IsUgmanagerActive(isManagedMode)
        If (isManagedMode) Then
            Dim ugmgr As UFUgmgr = ufSession.Ugmgr

            Dim rootFolderTag As Tag
            ugmgr.AskRootFolder(rootFolderTag)
            ugmgr.AskFolderName(rootFolderTag, homeFolder)
        End If

        dataObject.ComponentName = stockName
        dataObject.RenameComponentPartFlag = True

        dataObject.NativeFileName             = stockName
        dataObject.NativePath                 = "" ' An empty path means the current directory.
        dataObject.ManagedModeFolderName      = homeFolder + ":StockComponents"
        dataObject.ManagedModeItemName        = stockName
        dataObject.ManagedModeItemRevision    = "A"
        dataObject.ManagedModeItemType        = "Item"
        dataObject.ManagedModeItemDescription = "A sample description"
    End Sub

    '-----------------------------------------------------------------------------------------------
    Sub ApplicationEnterPlugin(application As CustomManager.Application)

        Dim message As String = "Entering the Mechanical application"
        If application = customManager.Application.Electrical Then
            message = "Entering the Electrical application"
        End If

        Echo(message)
    End Sub

    '-----------------------------------------------------------------------------------------------
    Sub ApplicationExitPlugin(application As CustomManager.Application)

        Dim message As String = "Exiting the Mechanical application"
        If application = customManager.Application.Electrical Then
            message = "Exiting the Electrical application"
        End If

        Echo(message)
    End Sub

    '-----------------------------------------------------------------------------------------------
    ' Writes the given string to the Listing Window and the syslog.
    '
    ' \param[in]
    '      stringToWrite
    '          The string to write.
    Sub Echo(ByVal stringToWrite As String)

        If Not listingWindow.IsOpen Then
            listingWindow.Open()
        End If

        listingWindow.WriteFullline(stringToWrite)

        Dim syslog As LogFile = Session.GetSession().LogFile
        syslog.WriteLine(stringToWrite)

    End Sub

    '-----------------------------------------------------------------------------------------------
    ' Tells NX when to unload your application.
    ' For Routing callbacks, plugins, And Design Rules, this MUST return AtTermination.
    Public Function GetUnloadOption(ByVal dummy As String) As Integer
        GetUnloadOption = NXOpen.Session.LibraryUnloadOption.AtTermination
    End Function

End Module
