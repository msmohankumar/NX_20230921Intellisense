 DeformMeshFromSolutionResults.vb - Deform a mesh based on the active Solution

   Description:
   This program is used to deform a mesh based on the results of the active Solution. 

   Instructions:
   1) Place a copy of SelectLoadCase.dlx in the %UGII_USER_DIR%\application folder
   2) Run this program (DeformMeshFromSolutionResults.vb) from within a SIM file  
      in NX Advanced Simulation. This is done via the Tools > Journal > Play command.
   3) The program will read the results for the active solution and for each node it
      will reposition each node to it given results location.

